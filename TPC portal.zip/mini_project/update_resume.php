<form action="submit_resume.php" method="post" enctype="multipart/form-data">
  Select PDF file to upload:
  <input type="file" name="fileToUpload" id="fileToUpload">
  <input type="submit" value="Upload PDF" name="submit">
</form>