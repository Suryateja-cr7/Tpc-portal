
<html>
    <body>
        <h2>Company Login Page</h2>
        <br><br><br>
        <form action="company_verify.php" method="post">
            Name: <input type="text" name="c_name"><br>
            Email: <input type="text" name="email"><br>
            Password: <input type="password" name="password"><br>
            Confirm Password: <input type="password" name="confirm_password"><br>
        <input type="submit", value="Login">
        </form>
    </body>
</html>
